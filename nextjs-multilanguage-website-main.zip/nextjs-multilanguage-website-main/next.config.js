module.exports = {
  i18n: {
    localeDetection: false,
    locales: ["en", "es"],
    defaultLocale: "en",
  },
};
